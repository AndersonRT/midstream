import dash
import dash_core_components as dcc
import dash_html_components as html

import colorlover as cl
import datetime as dt
import flask
import os
import pandas as pd
import time
from flask import request
import json
import redis
import requests as basic_requests

from server import app, server

from data_placeholder import df

header = html.Div([
    html.H2('Finance Explorer',
            style={'display': 'inline',
                   'float': 'left',
                   'font-size': '2.65em',
                   'margin-left': '7px',
                   'font-weight': 'bolder',
                   'font-family': 'Product Sans',
                   'color': "rgba(117, 117, 117, 0.95)",
                   'margin-top': '20px',
                   'margin-bottom': '0'}),
    html.Img(src="https://s3-us-west-1.amazonaws.com/plotly-tutorials/logo/new-branding/dash-logo-by-plotly-stripe.png",
             style={'height': '100px',
                    'float': 'right'
                   })])


stock_selector = dcc.Dropdown(
        id='stock-ticker-input',
        options=[{'label': s[0], 'value': str(s[1])}
                 for s in zip(df.Stock.unique(), df.Stock.unique())],
        value=['YHOO', 'GOOGL'],
        multi=True)

body = html.Div(html.Div(id='graphs'))

app.layout = html.Div([header, stock_selector, body])
import multiday_chart
#import intraday_chart





cache = redis.Redis(host='redis', port=6379, charset="utf-8", decode_responses=True)


def get_hit_count():
    retries = 5
    while True:
        try:
            return cache.incr('hits')
        except redis.exceptions.ConnectionError as exc:
            if retries == 0:
                raise exc
            retries -= 1
            time.sleep(0.5)


@server.route('/a')
def hello():
    count = get_hit_count()
    return 'Hello World! I have been seen {} times.\n'.format(count)


'''
import redis
ttl = 31104000 #one year
db = redis.Redis('localhost')

'''
def isInt(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

def update_robinhood_markets():
    url = 'https://api.robinhood.com/markets'
    resp = basic_requests.get(url)
    if resp.status_code == 200:
        markets_data = dict(json.loads(resp.content.decode('utf-8')))['results']
        markets_data = {v['mic'].lower():v for v in markets_data}

        for k,v in markets_data.items():
            cache.hmset(k, v)

        event = {'last_updated':int(time.time()),
                 'keys': str([*markets_data])}
        cache.hmset('markets',event)
    return cache.exists('markets')



@server.route('/api/<path:path>', methods = ['GET'])
def home(path):

    path=path.lower()

    if not cache.exists(path):
        state = None
        if path == 'markets':
            state = update_robinhood_markets()

        if not state:
            return "Error: thing doesn't exist"

    available_keys = cache.hget(path,'keys')
    return available_keys, 200


@server.route('/api/<path:path>/<path:path2>', methods = ['GET'])
def home2(path,path2):

    path=path.lower()
    path2=path2.lower()

    if not cache.exists(path):
        state = None
        if path == 'markets':
            state = update_robinhood_markets()

        if not state:
            return "Error: thing doesn't exist"

    if not cache.exists(path2):
        return "Error: thing doesn't exist"

    record = cache.hgetall(path2)
    return str(record), 200


